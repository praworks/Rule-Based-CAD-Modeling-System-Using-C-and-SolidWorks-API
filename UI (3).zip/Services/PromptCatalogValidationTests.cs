using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AICAD.Services
{
    [TestClass]
    public class PromptCatalogValidationTests
    {
        [TestMethod]
        public void ExecutePrompt_IsDistinctAndHasStepsAndOp()
        {
            var execute = PromptCatalog.GetSystemPrompt("execute_system");
            var decompose = PromptCatalog.GetSystemPrompt("decompose_system");

            Assert.IsFalse(string.IsNullOrWhiteSpace(execute), "execute_system prompt must be present");
            Assert.IsFalse(string.IsNullOrWhiteSpace(decompose), "decompose_system prompt must be present");

            Assert.AreNotEqual(decompose, execute, "execute_system must not be identical to decompose_system");

            Assert.IsTrue(execute.Contains("\"steps\""), "execute_system must require \"steps\"");
            Assert.IsTrue(execute.ToLowerInvariant().Contains("\"op\""), "execute_system must require step objects to use the 'op' field");

            Assert.IsTrue(decompose.ToLowerInvariant().Contains("feature task") || decompose.ToLowerInvariant().Contains("feature_type"), "decompose_system must reference feature task contract");
            Assert.IsFalse(decompose.Contains("\"steps\""), "decompose_system must NOT reference \"steps\"");
        }
    }
}
