using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;

namespace AICAD.Services
{
    internal static class PromptCatalog
    {
        private static readonly Lazy<JObject> Catalog = new Lazy<JObject>(LoadCatalog);

        public static string GetSystemPrompt(string key) => GetString("systemPrompts", key);

        public static string GetTemplate(string key) => GetString("templates", key);

        private static JObject LoadCatalog()
        {
            var path = LocateCatalogPath();
            if (string.IsNullOrWhiteSpace(path))
                return new JObject();

            try
            {
                var content = File.ReadAllText(path);
                var parsed = JObject.Parse(content);
                ValidateSystemPrompts(parsed);
                return parsed;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load PromptCatalog from '{path}': {ex.Message}", ex);
            }
        }

        private static void ValidateSystemPrompts(JObject catalog)
        {
            if (catalog == null)
                return;

            var sys = catalog["systemPrompts"] as JObject;
            if (sys == null)
                return;

            string Get(string k)
            {
                try
                {
                    var t = sys[k];
                    return t?.Value<string>() ?? string.Empty;
                }
                catch
                {
                    return string.Empty;
                }
            }

            var decompose = Get("decompose_system").Trim();
            var execute = Get("execute_system").Trim();

            // decompose: must NOT contain steps/op/thinking and should reference feature task contract
            var decompLower = decompose.ToLowerInvariant();
            if (decompLower.Contains("\"steps\"") || decompLower.Contains("\"op\"") || decompLower.Contains("thinking"))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'decompose_system' contains executor tokens (\"steps\", \"op\", or 'thinking'). Decompose prompt must be a schematic feature-task contract only.");
            }
            if (!decompLower.Contains("feature task") && !decompLower.Contains("feature_type") && !decompLower.Contains("feature task objects"))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'decompose_system' does not describe feature task output (expected phrase 'feature task' or 'feature_type').");
            }

            // execute: must contain steps and op, must not request feature_type inside steps
            var execLower = execute.ToLowerInvariant();
            if (!execLower.Contains("\"steps\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must mention \"steps\" in its contract.");
            }
            if (!execLower.Contains("\"op\"") && !execLower.Contains(" op\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must require steps use the \"op\" field (never use 'command').");
            }
            if (execLower.Contains("feature_type") || execLower.Contains("feature task"))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' appears to reference decomposition feature-task content. Execute prompt must be distinct and focused on 'thinking' + 'steps'.");
            }
            if (execLower.Contains("\"command\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must use field name 'op' and must not use 'command'.");
            }
        }

        private static string LocateCatalogPath()
        {
            var baseDir = AppContext.BaseDirectory;
            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var dir = new DirectoryInfo(baseDir); dir != null; dir = dir.Parent)
            {
                var candidate = Path.Combine(dir.FullName, "Config", "PromptCatalog.json");
                if (visited.Contains(candidate))
                    continue;
                visited.Add(candidate);
                if (File.Exists(candidate))
                    return candidate;
            }

            var fallback = Path.Combine(Environment.CurrentDirectory, "Config", "PromptCatalog.json");
            return File.Exists(fallback) ? fallback : null;
        }

        private static string GetString(string section, string key)
        {
            try
            {
                var node = Catalog.Value;
                var token = node?[section]?[key];
                if (token == null)
                    return string.Empty;
                return token.Value<string>() ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
