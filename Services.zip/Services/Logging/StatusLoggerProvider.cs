using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace AICAD.Services.Logging
{
    internal sealed class StatusLoggerProvider : ILoggerProvider, ISupportExternalScope
    {
        private IExternalScopeProvider _scopeProvider = new LoggerExternalScopeProvider();
        private readonly ConcurrentDictionary<string, StatusLogger> _loggers = new ConcurrentDictionary<string, StatusLogger>(StringComparer.Ordinal);

        public ILogger CreateLogger(string categoryName)
        {
            return _loggers.GetOrAdd(categoryName, name => new StatusLogger(name, () => _scopeProvider));
        }

        public void Dispose()
        {
            _loggers.Clear();
        }

        public void SetScopeProvider(IExternalScopeProvider scopeProvider)
        {
            _scopeProvider = scopeProvider ?? new LoggerExternalScopeProvider();
        }

        private sealed class StatusLogger : ILogger
        {
            private readonly string _category;
            private readonly Func<IExternalScopeProvider> _scopeProviderFactory;

            public StatusLogger(string category, Func<IExternalScopeProvider> scopeProviderFactory)
            {
                _category = category;
                _scopeProviderFactory = scopeProviderFactory;
            }

            public IDisposable BeginScope<TState>(TState state)
            {
                return _scopeProviderFactory().Push(state);
            }

            public bool IsEnabled(LogLevel logLevel) => true;

            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
            {
                try
                {
                    var message = formatter?.Invoke(state, exception) ?? string.Empty;
                    var sanitized = LogRedactor.Sanitize(message);
                    var scopeData = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                    _scopeProviderFactory().ForEachScope((scope, dict) =>
                    {
                        if (scope is IEnumerable<KeyValuePair<string, object>> kvpEnumerable)
                        {
                            foreach (var kvp in kvpEnumerable)
                            {
                                if (!dict.ContainsKey(kvp.Key)) dict[kvp.Key] = kvp.Value;
                            }
                        }
                        else
                        {
                            var key = scope?.GetType().Name ?? "scope";
                            if (!dict.ContainsKey(key)) dict[key] = scope;
                        }
                    }, scopeData);

                    var ts = DateTime.Now.ToString("HH:mm:ss.fff");
                    var corr = scopeData.TryGetValue("correlationId", out var c) ? c?.ToString() : null;
                    var op = scopeData.TryGetValue("operation", out var o) ? o?.ToString() : null;
                    var stage = scopeData.TryGetValue("stage", out var st) ? st?.ToString() : null;
                    var provider = scopeData.TryGetValue("provider", out var pr) ? pr?.ToString() : null;
                    var sb = new System.Text.StringBuilder();
                    sb.Append(ts).Append("  ").Append(logLevel.ToString().PadRight(5));
                    sb.Append("  corr=").Append(string.IsNullOrWhiteSpace(corr) ? "-" : corr);
                    sb.Append(" op=").Append(string.IsNullOrWhiteSpace(op) ? _category : op);
                    if (!string.IsNullOrWhiteSpace(stage)) sb.Append(" stage=").Append(stage);
                    if (!string.IsNullOrWhiteSpace(provider)) sb.Append(" provider=").Append(provider);
                    sb.Append("  ").Append(sanitized);
                    if (exception != null)
                    {
                        var exLine = $"{exception.GetType().Name}: {exception.Message}";
                        sb.Append(" err=").Append(LogRedactor.Sanitize(exLine));
                    }

                    AddinStatusLogger.Log(string.Empty, sb.ToString());
                }
                catch
                {
                    // Swallow any logging failures
                }
            }
        }
    }
}
