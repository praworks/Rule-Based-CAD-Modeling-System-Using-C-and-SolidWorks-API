using System;
using Newtonsoft.Json.Linq;
using SolidWorks.Interop.sldworks;

namespace AICAD.Services.Operations.Sketching
{
    /// <summary>
    /// Handler for "sketch_begin" operation - starts sketch editing mode
    /// </summary>
    public class SketchBeginHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (model == null)
                    return OperationResult.CreateFailure("Model not initialized");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                sketchMgr.InsertSketch(true);
                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"sketch_begin failed: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Handler for "sketch_end" operation - finishes sketch editing and creates sketch feature
    /// </summary>
    public class SketchEndHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Not currently in sketch mode");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                sketchMgr.InsertSketch(true);
                return OperationResult.CreateSuccess(stillInSketch: false);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"sketch_end failed: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Handler for "rectangle_center" operation - draws rectangle centered at (cx, cy)
    /// </summary>
    public class RectangleCenterHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to draw rectangle");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                double cx = ToMeters(step.Value<double?>("cx") ?? 0);
                double cy = ToMeters(step.Value<double?>("cy") ?? 0);
                double w = ToMeters(step.Value<double?>("w") ?? 0);
                double h = ToMeters(step.Value<double?>("h") ?? 0);

                if (w <= 0 || h <= 0)
                    return OperationResult.CreateFailure("Rectangle width and height must be > 0");

                double x1 = cx - w / 2.0;
                double y1 = cy - h / 2.0;
                double x2 = cx + w / 2.0;
                double y2 = cy + h / 2.0;

                var rect = sketchMgr.CreateCenterRectangle(cx, cy, 0, x2, y2, 0);
                if (rect == null)
                    return OperationResult.CreateFailure("Failed to create rectangle");

                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"rectangle_center failed: {ex.Message}");
            }
        }

        private static double ToMeters(double mm) => mm / 1000.0;
    }

    /// <summary>
    /// Handler for "circle_center" operation - draws circle at (cx, cy) with given radius or diameter
    /// </summary>
    public class CircleCenterHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to draw circle");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                double cx = ToMeters(step.Value<double?>("cx") ?? 0);
                double cy = ToMeters(step.Value<double?>("cy") ?? 0);
                double r = step["r"] != null ? 
                    ToMeters(step.Value<double>("r")) : 
                    (step["diameter"] != null ? 
                        ToMeters(step.Value<double>("diameter")) / 2.0 : 0);

                if (r <= 0)
                    return OperationResult.CreateFailure("Circle radius or diameter must be > 0");

                object circ = sketchMgr.CreateCircleByRadius(cx, cy, 0, r);
                if (circ == null)
                    return OperationResult.CreateFailure("Failed to create circle");

                // If caller requested a construction (center) circle, attempt to mark it as construction geometry.
                try
                {
                    var isConstruction = step.Value<bool?>("construction") ?? step.Value<bool?>("construction_circle") ?? false;
                    if (isConstruction)
                    {
                        try
                        {
                            // Some interop types expose SetConstruction(bool). Try to call it reflectively.
                            var mi = circ.GetType().GetMethod("SetConstruction");
                            if (mi != null)
                            {
                                mi.Invoke(circ, new object[] { true });
                            }
                            else
                            {
                                // Fallback: try to set property 'Construction' if present
                                var pi = circ.GetType().GetProperty("Construction");
                                if (pi != null && pi.CanWrite) pi.SetValue(circ, true);
                            }
                        }
                        catch { }
                    }
                }
                catch { }

                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"circle_center failed: {ex.Message}");
            }
        }

        private static double ToMeters(double mm) => mm / 1000.0;
    }

    /// <summary>
    /// Handler for "line" operation - draws line segment between two points
    /// </summary>
    public class LineHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to draw line");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                double x1 = ToMeters(step.Value<double?>("x1") ?? 0);
                double y1 = ToMeters(step.Value<double?>("y1") ?? 0);
                double x2 = ToMeters(step.Value<double?>("x2") ?? 0);
                double y2 = ToMeters(step.Value<double?>("y2") ?? 0);

                var line = sketchMgr.CreateLine(x1, y1, 0, x2, y2, 0);
                if (line == null)
                    return OperationResult.CreateFailure("Failed to create line");

                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"line failed: {ex.Message}");
            }
        }

        private static double ToMeters(double mm) => mm / 1000.0;
    }

    /// <summary>
    /// Handler for "construction_line" operation - draws a construction (center) line between two points
    /// </summary>
    public class ConstructionLineHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to draw construction line");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                double x1 = ToMeters(step.Value<double?>("x1") ?? 0);
                double y1 = ToMeters(step.Value<double?>("y1") ?? 0);
                double x2 = ToMeters(step.Value<double?>("x2") ?? 0);
                double y2 = ToMeters(step.Value<double?>("y2") ?? 0);

                // Create a SOLIDWORKS centerline which is marked as construction geometry by default
                var line = sketchMgr.CreateCenterLine(x1, y1, 0, x2, y2, 0);
                if (line == null)
                    return OperationResult.CreateFailure("Failed to create construction line");

                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"construction_line failed: {ex.Message}");
            }
        }

        private static double ToMeters(double mm) => mm / 1000.0;
    }

    /// <summary>
    /// Handler for "arc" operation - draws arc (not yet fully specified)
    /// </summary>
    public class ArcHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to draw arc");
                if (sketchMgr == null)
                    return OperationResult.CreateFailure("Sketch manager not available");

                double cx = ToMeters(step.Value<double?>("cx") ?? 0);
                double cy = ToMeters(step.Value<double?>("cy") ?? 0);
                double r = ToMeters(step.Value<double?>("r") ?? step.Value<double?>("radius") ?? 0);
                double startDeg = step.Value<double?>("start_angle") ?? step.Value<double?>("start") ?? 0;
                double endDeg = step.Value<double?>("end_angle") ?? step.Value<double?>("end") ?? 90;

                if (r <= 0)
                    return OperationResult.CreateFailure("Arc radius must be > 0");

                double startRad = startDeg * Math.PI / 180.0;
                double endRad = endDeg * Math.PI / 180.0;

                double sx = cx + r * Math.Cos(startRad);
                double sy = cy + r * Math.Sin(startRad);
                double ex = cx + r * Math.Cos(endRad);
                double ey = cy + r * Math.Sin(endRad);

                var arc = sketchMgr.CreateArc(cx, cy, 0, sx, sy, 0, ex, ey, 0, 0);
                if (arc == null)
                    return OperationResult.CreateFailure("Failed to create arc");

                return OperationResult.CreateSuccess(stillInSketch: true);
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"arc failed: {ex.Message}");
            }
        }

        private static double ToMeters(double mm) => mm / 1000.0;
    }

    // DimensionHandler extracted to its own file

    /// <summary>
    /// Handler for "constraint" operation - adds constraint to sketch geometry
    /// </summary>
    public class ConstraintHandler : IOperationHandler
    {
        public OperationResult Execute(JObject step, IModelDoc2 model, ISketchManager sketchMgr, IFeatureManager featMgr, bool inSketch)
        {
            try
            {
                if (!inSketch)
                    return OperationResult.CreateFailure("Must be in sketch mode to add constraint");

                // TODO: Implement sketch constraints (horizontal, vertical, perpendicular, etc.)
                return OperationResult.CreateFailure("Constraint operation not yet implemented");
            }
            catch (Exception ex)
            {
                return OperationResult.CreateFailure($"constraint failed: {ex.Message}");
            }
        }
    }
}
