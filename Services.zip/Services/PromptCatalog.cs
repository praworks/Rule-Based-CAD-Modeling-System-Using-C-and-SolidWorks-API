using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;

namespace AICAD.Services
{
    internal static class PromptCatalog
    {
        private static readonly Lazy<JObject> Catalog = new Lazy<JObject>(LoadCatalog);

        public static string GetSystemPrompt(string key) => GetString("systemPrompts", key);

        public static string GetSystemPromptForFeature(string featureKey)
        {
            try
            {
                var node = Catalog.Value;
                var byFeature = node?["systemPromptsByFeature"] as JObject;
                if (byFeature == null) return string.Empty;
                var token = byFeature[featureKey];
                if (token == null) return string.Empty;
                return token.Value<string>() ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        public static string GetTemplate(string key) => GetString("templates", key);

        private static JObject LoadCatalog()
        {
            var path = LocateCatalogPath();
            if (string.IsNullOrWhiteSpace(path))
                return new JObject();

            try
            {
                var content = File.ReadAllText(path);
                var parsed = JObject.Parse(content);
                ValidateSystemPrompts(parsed);
                return parsed;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load PromptCatalog from '{path}': {ex.Message}", ex);
            }
        }

        private static void ValidateSystemPrompts(JObject catalog)
        {
            if (catalog == null)
                return;

            var sys = catalog["systemPrompts"] as JObject;
            if (sys == null)
                return;

            string Get(string k)
            {
                try
                {
                    var t = sys[k];
                    return t?.Value<string>() ?? string.Empty;
                }
                catch
                {
                    return string.Empty;
                }
            }

            var decompose = Get("decompose_system").Trim();
            var execute = Get("execute_system").Trim();

            // decompose: must NOT contain steps/op/thinking and should reference feature task contract
            var decompLower = decompose.ToLowerInvariant();
            if (decompLower.Contains("\"steps\"") || decompLower.Contains("\"op\"") || decompLower.Contains("thinking"))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'decompose_system' contains executor tokens (\"steps\", \"op\", or 'thinking'). Decompose prompt must stay schematic.");
            }
            if (!decompLower.Contains("\"features\"") || !decompLower.Contains("needs_description") || !decompLower.Contains("\"question\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'decompose_system' must reference 'features', 'needs_description', and 'question'.");
            }

            // execute: must contain steps and op, must not request feature_type inside steps
            var execLower = execute.ToLowerInvariant();
            if (!execLower.Contains("\"steps\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must mention \"steps\" in its contract.");
            }
            if (!execLower.Contains("\"op\"") && !execLower.Contains(" op\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must require steps use the \"op\" field (never use 'command').");
            }
            if (!execLower.Contains("clarification_needed"))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must describe the clarification flow (clarification_needed).");
            }
            if (!execLower.Contains("\"feature_index\"") || !execLower.Contains("\"feature_type\"") || !execLower.Contains("\"questions\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must mention feature_index, feature_type, and questions for clarifications.");
            }
            if (execLower.Contains("\"command\""))
            {
                throw new InvalidOperationException("PromptCatalog validation failed: 'execute_system' must use field name 'op' and must not use 'command'.");
            }
        }

        private static string LocateCatalogPath()
        {
            // First, try the folder where this assembly is located. This makes the
            // catalog discoverable when the add-in is loaded inside another process
            // (for example SolidWorks) where AppContext.BaseDirectory may not point
            // to the add-in output directory.
            try
            {
                var asmLocation = typeof(PromptCatalog).Assembly.Location;
                if (!string.IsNullOrWhiteSpace(asmLocation))
                {
                    var asmDir = Path.GetDirectoryName(asmLocation);
                    if (!string.IsNullOrWhiteSpace(asmDir))
                    {
                        var candidate = Path.Combine(asmDir, "Config", "PromptCatalog.json");
                        if (File.Exists(candidate)) return candidate;
                        // also check sibling path (catalog directly next to assembly)
                        candidate = Path.Combine(asmDir, "PromptCatalog.json");
                        if (File.Exists(candidate)) return candidate;
                    }
                }
            }
            catch { }

            var baseDir = AppContext.BaseDirectory;
            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var dir = new DirectoryInfo(baseDir); dir != null; dir = dir.Parent)
            {
                var candidate = Path.Combine(dir.FullName, "Config", "PromptCatalog.json");
                if (visited.Contains(candidate))
                    continue;
                visited.Add(candidate);
                if (File.Exists(candidate))
                    return candidate;
            }

            var fallback = Path.Combine(Environment.CurrentDirectory, "Config", "PromptCatalog.json");
            if (File.Exists(fallback)) return fallback;

            // as a last resort, check repository-relative location using current assembly directory
            try
            {
                var repoCandidate = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "Config", "PromptCatalog.json");
                var full = Path.GetFullPath(repoCandidate);
                if (File.Exists(full)) return full;
            }
            catch { }

            return null;
        }

        private static string GetString(string section, string key)
        {
            try
            {
                var node = Catalog.Value;
                var token = node?[section]?[key];
                if (token == null)
                {
                    try
                    {
                        var path = LocateCatalogPath();
                        System.Diagnostics.Trace.TraceWarning($"PromptCatalog missing key: section={section} key={key} catalogPath={(path ?? "not found")}");
                    }
                    catch { }
                    return string.Empty;
                }
                return token.Value<string>() ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
